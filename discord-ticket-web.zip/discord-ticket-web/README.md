# Discord Ticket Web Portal

A clean, modern support ticket website that lives on **your domain** and talks live with your Discord server.

Users open tickets on the website → a private channel is created in Discord → staff reply in Discord → messages appear instantly on the website (and vice-versa).

---

## Features

- Dark blended blue gradient background
- 2D pixel cat that walks back and forth at the bottom
- Login / Sign-up style entry (name based, no password needed)
- Create ticket form
- Real-time bidirectional chat (Website ↔ Discord)
- Beautiful glassmorphism UI
- Fully responsive

---

## Project Structure

```
discord-ticket-web/
├── public/
│   ├── index.html      # Frontend
│   ├── style.css       # Dark blue theme + animations
│   └── app.js          # Pixel cat + Socket.io client
├── server/
│   ├── index.js        # Express + Discord.js + Socket.io
│   ├── package.json
│   └── .env.example
└── README.md
```

---

## 1. Create a Discord Bot

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. **New Application** → give it a name
3. Go to **Bot** tab → **Add Bot**
4. Reset Token → **copy the token** (this is `DISCORD_TOKEN`)
5. Under **Privileged Gateway Intents** enable:
   - Message Content Intent
   - Server Members Intent (optional but recommended)
6. Go to **OAuth2 → URL Generator**
   - Scopes: `bot`
   - Permissions:  
     `Manage Channels`, `Send Messages`, `Read Message History`, `View Channels`, `Embed Links`
7. Copy the generated URL and invite the bot to **your server**

---

## 2. Get the IDs you need

Enable **Developer Mode** in Discord (User Settings → Advanced → Developer Mode).

- **GUILD_ID** → right-click your server icon → Copy Server ID
- **TICKET_CATEGORY_ID** → create a category called `Tickets` (or any name) → right-click the category → Copy Channel ID
- **STAFF_ROLE_ID** (optional) → right-click the role that should see tickets → Copy Role ID

---

## 3. Setup the server

```bash
cd server
cp .env.example .env
# Edit .env with your real values
nano .env          # or use any editor
```

Install dependencies:

```bash
npm install
```

Start the portal:

```bash
npm start
```

You should see:

```
✅ Discord bot online as YourBot#1234
🚀 Ticket portal running at http://localhost:3000
```

Open `http://localhost:3000` in your browser.

---

## 4. Put it on your domain

You already have a domain and a server that hosts your bot.

### Option A – Same machine as your bot

Just run this Node process on the same VPS / dedicated server.

Point your domain (or a subdomain like `support.yourdomain.com`) to the server IP and proxy port 3000 with Nginx:

```nginx
server {
    listen 80;
    server_name support.yourdomain.com;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Then get free SSL with Certbot.

### Option B – Separate server

Same idea — just make sure the machine can reach Discord API and has Node.js installed.

---

## How the chat works

1. User enters a name on the website and creates a ticket
2. Bot instantly creates a private text channel under your Ticket category
3. Staff can see the channel (if they have the Staff role or Manage Channels)
4. Anything staff type in that Discord channel appears on the website in real time
5. Anything the user types on the website is posted into the Discord channel

---

## Optional improvements you can ask me for later

- Persistent ticket history (SQLite / MongoDB)
- Discord OAuth login
- Ticket claiming / closing buttons inside Discord
- Transcript generation
- Multiple languages
- Custom branding / logo

---

Made clean & professional by **Synvo**
